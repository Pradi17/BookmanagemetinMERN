This All Project are made using React and Vite 
fro Styling of this Tailned CSS is Used 
For Bakend To Fech Data From Databased We used The Node Js And For DB Process We Used the Mongo DB
Some Addinal Funactnalites Like email js are used in by using proper key
for Runing the front end give the cmd npm run dev
forbackend the cmd is npm start