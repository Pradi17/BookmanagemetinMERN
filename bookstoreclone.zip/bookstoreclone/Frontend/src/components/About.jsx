import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import Course from './Course'
import banner from "../../public/Banner.png";
const About = () => {
  return (
    <>
      <Navbar />
      <div className=" min-h-screen">
      <div className="flex w-full h-screen items-center justify-center">
      <div className="flex w-11/12 h-5/6">
      <div className="flex-1 h-14 bg-gradient-to-r from-purple-500 to-pink-500flex items-center justify-center m-2 mt-12 ">
      <h1 className="text-2xl  md:text-4xl ">
      Why Choose, {" "}
            <span className="text-pink-500"> Us?</span>
          </h1>
          <p className="mt-12">
          •	Convenience: Read anytime, anywhere. Our eBooks are compatible with all major devices including tablets, e-readers, and smartphones.<br /><br />

          •	Quality: We partner with top publishers and authors to bring you high-quality content.<br /><br />

          •	Customer Support: Our dedicated customer support team is here to assist you with any queries or issues you may have.<br /><br />

          </p>
        </div>
        <div className="flex-1 bg-500 flex items-center justify-center m-2">
        <img
            src={banner}
            className="md:w-[550px] md:h-[460px] md:ml-12"
            alt="JADU"
          />
        </div>
      </div>
    </div>
    <div className="flex w-full h-screen items-center justify-center">
      <div className="flex w-11/12 h-5/6">
      <div className="flex-1 bg-500 flex items-center justify-center m-2">
        <img
            src={banner}
            className="md:w-[550px] md:h-[460px] md:ml-12"
            alt="JADU"
          />
        </div>
        <div className="flex-1 h-14 bg-gradient-to-r from-purple-500 to-pink-500flex items-center justify-center m-2">
        <h1 className="text-2xl  md:text-4xl ">
      What we, {" "}
            <span className="text-pink-500">Offer</span>
          </h1>
          <p className="mt-12">
          •	Extensive Library: Discover thousands of eBooks from bestsellers to hidden gems across genres like fiction, non-fiction, romance, science fiction, self-help, and more.<br /><br />
          •	User-Friendly Experience: Our platform is designed with you in mind. Easily browse, search, and download eBooks with our intuitive interface.<br /><br />
          •	Affordable Prices: Enjoy competitive pricing and regular discounts, making reading more affordable than ever.
          •	Exclusive Content: Access exclusive eBooks and early releases from your favorite authors.<br /><br />
          •	Community and Reviews: Join a community of avid readers. Share your thoughts, write reviews, and engage with others.<br /><br />

          </p>
        </div>
      </div>
    </div>
     <div className="flex w-full h-screen items-center justify-center">
      <div className="flex w-11/12 h-5/6">
      <div className="flex-1 h-14 bg-gradient-to-r from-purple-500 to-pink-500flex items-center justify-center m-2">
      <h1 className="text-2xl  md:text-4xl ">
      Join Our  {" "}
            <span className="text-pink-500">Community</span>
          </h1>
          <p className="mt-12">
            •	Exclusive Access: Get early access to new releases, exclusive content, and special editions that are only available to our community members.<br /><br />
            •	Book Clubs and Reading Groups: Join book clubs and reading groups tailored to your interests. Participate in lively discussions and meet fellow readers who share your passions.<br /><br />
            •	Author Events and Webinars: Attend virtual events, live webinars, and Q&A sessions with your favorite authors. Gain insights into their writing process and  upcoming projects.<br /><br />
            •	Personalized Book Recommendations: Receive personalized book recommendations based on your reading history and preferences. Discover new authors and genres you’ll love.<br /><br />
            •	Member-Only Discounts and Promotions: Enjoy special discounts, promotions, and deals exclusively for community members. Save on your favorite books and discover            new ones at great prices.<br /><br />
            •	Interactive Features: Engage with interactive features such as polls, quizzes, and reading challenges. Track your reading progress and achieve milestones.<br /><br />

          </p>
        </div>
        <div className="flex-1 bg-500 flex items-center justify-center m-2">
        <img
            src={banner}
            className="md:w-[550px] md:h-[460px] md:ml-12"
            alt="JADU"
          />
        </div>
      </div>
    </div>
      </div>
      <Footer />
    </>
  )
}

export default About